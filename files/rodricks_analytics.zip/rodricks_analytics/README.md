# RODRICKS ANALYTICS

### Statistical Analysis · Research Consultancy · Data Insights

![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=flat&logo=python&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-3.0%2B-000000?style=flat&logo=flask&logoColor=white)
![Responsive](https://img.shields.io/badge/Responsive-Mobile%20%2B%20Desktop-0ea5e9?style=flat)

Professional website for **Rodricks Analytics** — a statistical analysis and research consultancy serving organizations, institutions, researchers, and policy stakeholders across Africa.

---

## Quick Start

```bash
# Clone
git clone https://github.com/kevwasonga/rodricks_analytics.git
cd rodricks_analytics

# Setup
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Run
python app.py
# → http://localhost:5000
```

## Production

```bash
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

## Structure

```
rodricks_analytics/
├── app.py                    # Flask backend
├── requirements.txt
├── templates/
│   ├── base.html             # Layout, nav, footer
│   └── index.html            # All page sections
└── static/
    ├── css/style.css         # Full stylesheet (dark data theme)
    └── js/main.js            # Interactions + canvas animation
```

## Features

- **Hero Section**: Animated data network canvas, live regression terminal widget, floating stat labels
- **Custom D Logo**: SVG "D" built from data bars + scatter plot trendline
- **Data Visualizations**: Inline bar charts, line charts, donut charts, map scatter in case studies
- **Skill Bars**: Animated proficiency bars for R, SPSS, STATA, JASP, etc.
- **WhatsApp Integration**: Floating FABs + contact CTAs (+254 794 627947, +254 773 625138)
- **Fully Responsive**: Mobile hamburger, adaptive grids, touch-friendly
- **Dark Analytics Theme**: Space Grotesk + Syne + Space Mono type stack

## Contact

- **Phone**: +254 794 627 947 / +254 773 625 138  
- **Email**: rodricks.analytics@gmail.com  
- **WhatsApp**: [0794627947](https://wa.me/254794627947)

---
*© 2026 Rodricks Analytics. Transform Data Into Intelligence.*
